let focusTime = 25 * 60;
    let breakTime = 5 * 60;
    let time = focusTime;
    let isFocus = true;
    let interval;
    let cycleCount = 0;

    function formatTime(t) {
      const m = String(Math.floor(t / 60)).padStart(2, '0');
      const s = String(t % 60).padStart(2, '0');
      return `${m}:${s}`;
    }

    function updateCircle() {
      const percent = ((isFocus ? time : breakTime - time) / (isFocus ? focusTime : breakTime)) * 100;
      document.documentElement.style.setProperty('--percent', percent);
      const circle = document.getElementById('circle');
      if (time <= 10) {
        circle.classList.add('blinking');
        document.documentElement.style.setProperty('--timer-color', 'var(--warn-color)');
      } else {
        circle.classList.remove('blinking');
        document.documentElement.style.setProperty('--timer-color', isFocus ? 'var(--danger-color)' : 'var(--accent-color)');
      }
    }

    function startSound() {
      const startSound = document.getElementById("start-sound");
      if (startSound) {
          startSound.currentTime = 0;  // 소리 초기화
          startSound.play().catch(error => console.error("오디오 재생 오류:", error));  // 오류 확인
      } else {
          console.error("start-sound 요소를 찾을 수 없습니다!");
      }
    }  

    function startTimer() {
      
    
      clearInterval(interval);  // 기존 인터벌을 정리
      interval = setInterval(() => {
        time--;
        document.getElementById('timeDisplay').textContent = formatTime(time);
        updateCircle();
    
        if (time <= 0) {
          clearInterval(interval);  // 타이머 종료 시 인터벌 정리
    
          const doneSound = document.getElementById("change-sound");  // 완료 효과음
          doneSound.currentTime = 0;
          doneSound.play();  // 완료 소리 재생
    
          if (isFocus) {
            cycleCount++;
            document.getElementById('cycleCount').textContent = `🌱 집중 사이클: ${cycleCount}`;
          }
    
          isFocus = !isFocus;
          time = isFocus ? focusTime : (cycleCount % 4 === 0 ? 30 * 60 : breakTime);
    
          startTimer();  // 다음 사이클 시작
        }
      }, 1000);
    }
    

    function resetTimer() {
      clearInterval(interval);
      const startSound = document.getElementById("stop-sound");
      startSound.currentTime = 0;  // 소리 초기화
      startSound.play();  // 시작 효과음 재생
      isFocus = true;
      time = focusTime;
      document.getElementById('timeDisplay').textContent = formatTime(time);
      updateCircle();
    }

    function toggleFocus() {
      clearInterval(interval);
      isFocus = !isFocus;
      time = isFocus ? focusTime : breakTime;
      document.getElementById('timeDisplay').textContent = formatTime(time);
      updateCircle();
    }

    function addTodo() {
      const input = document.getElementById('todoInput');
      const text = input.value.trim();
      if (!text) return;
      const li = document.createElement('li');
      const check = document.createElement('input');
      check.type = 'checkbox';
      check.onchange = saveTodos;
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = '🗑';
      deleteBtn.style.marginLeft = 'auto';
      deleteBtn.onclick = () => {
        li.remove();
        saveTodos();
      };
      li.appendChild(check);
      li.appendChild(document.createTextNode(text));
      li.appendChild(deleteBtn);
      document.getElementById('todoList').appendChild(li);
      input.value = '';
      saveTodos();
    }

    function saveTodos() {
      const date = document.getElementById('datePicker').value || new Date().toISOString().split('T')[0];
      const items = [];
      document.querySelectorAll('#todoList li').forEach(li => {
        const checkbox = li.querySelector('input');
        const label = li.childNodes[1];
        items.push({ text: label.textContent, done: checkbox.checked });
      });
      localStorage.setItem(`todos-${date}`, JSON.stringify(items));
      updateProgressBar(items);
    }

    function updateProgressBar(items) {
      const done = items.filter(item => item.done).length;
      const percent = items.length ? (done / items.length) * 100 : 0;
      document.getElementById('progressBar').style.width = `${percent}%`;
    }

    function loadTodos() {
      const date = document.getElementById('datePicker').value || new Date().toISOString().split('T')[0];
      const data = JSON.parse(localStorage.getItem(`todos-${date}`)) || [];
      const list = document.getElementById('todoList');
      list.innerHTML = '';
      data.forEach(item => {
        const li = document.createElement('li');
        const check = document.createElement('input');
        check.type = 'checkbox';
        check.checked = item.done;
        check.onchange = saveTodos;
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '🗑';
        deleteBtn.style.marginLeft = 'auto';
        deleteBtn.onclick = () => {
          li.remove();
          saveTodos();
        };
        li.appendChild(check);
        li.appendChild(document.createTextNode(item.text));
        li.appendChild(deleteBtn);
        list.appendChild(li);
      });
      updateProgressBar(data);
    }

    function toggleMode() {
      document.body.classList.toggle('dark');
    }

    function displayRandomQuote() {
      const quotes = [
        "시작이 반이다.",
        "포기하지 말고 계속해보세요!",
        "작은 걸음이 큰 변화를 만든다.",
        "오늘도 한 걸음 전진!",
        "집중은 최고의 습관입니다.",
        "당신은 생각보다 강해요.",
        "매일 1%의 성장으로 목표를 이룹니다.",
        "생산성은 선택이 아니라 습관입니다.",
        "멈추지 말라고."
      ];
      const quote = quotes[Math.floor(Math.random() * quotes.length)];
      document.getElementById("quote").textContent = quote;
    }

    document.getElementById('datePicker').addEventListener('change', loadTodos);

    window.onload = () => {
      document.getElementById('datePicker').value = new Date().toISOString().split('T')[0];
      loadTodos();
      updateCircle();
      document.getElementById('timeDisplay').textContent = formatTime(time);
      document.getElementById('cycleCount').textContent = `🌱 집중 사이클: ${cycleCount}`;
      displayRandomQuote();
    };


